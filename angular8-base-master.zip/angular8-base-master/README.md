# Project angular 8.2.13

Angular design 8.2.13 angular, with standard angular CLI template.
